import React from "react";
import Navbar from "./Components/Navbar/Navbar";
import Hero from "./Components/Hero/Hero";
import { Images } from "./Assests/Images";
import Community_card from "./Components/Community_card/Community_card";
import Advisor from './Components/Advisor/Advisor'
import Feature_card from "./Components/Feature_card/Feature_card";
import Discover_Categories from "./Components/Discover_Categories/Discover_Categories";
import Team from './Components/Team/Team'
import Token from "./Components/LFG_token/token";
import Tabs from "./Components/Tabs/Tabs";
import "./App.css";
const App = () => {
  return (
    <div className="main relative">
      <img src={Images.Circle} className="absolute right-0 w-6/12" />
      <Navbar />
      <Hero />
      <div className="px-8 sm:px-20 lg:px-44 mx-2 py-12 lg:py-8 border-red-300">
        <h3 className="text-3xl leading-6 font-medium text-center py-10 text-white">
          Our Community
        </h3>
        <ul
          role="list"
          className="grid grid-cols-1 gap-5 sm:grid-cols-2 md:grid-cols-3"
        >
          <Community_card />
          <Community_card />
          <Community_card />
        </ul>
      </div>
      <div className="px-8 sm:px-20 lg:px-44 mx-2 py-12 lg:py-8 border-red-300">
        <h3 className="text-3xl leading-6 font-medium text-center py-10 text-white">
          Features
        </h3>
        <Feature_card />
      </div>

      <main className="lg:relative px-8 sm:px-20 lg:px-44 mx-2 ">
        <div className="mx-auto max-w-7xl flex w-full pt-16 text-center lg:py-12 lg:text-left">
          <div className="lg:w-1/2">
            <h3 className="text-3xl hover-h leading-6 font-medium pb-10 text-white">
              $LFG Token
            </h3>
            <p className="text-gray-300 text-sm leading-6 ">
              Lorem is the SwapNFT ERC-20 native token built on the Ethereum
              blockchain. Use ART Coins on the SwapNFT platform and receive ‘no
              fees’ swaps, get rewarded with staking incentives, receive
              exclusive access in our Auction House feature, and unique
              customizations for your avatar. ART Tokens will also be used to
              mint NFTs on the platform and 50% of the $ART minting fee will be
              burned, increasing the scarcity and value of the coin over time.{" "}
            </p>
            <div className="flex my-5">
              <Token />
            </div>
          </div>
          {/* <div className="lg:w-1/2 border-4"></div> */}
        </div>
      </main>

      <div className="px-8 sm:px-20 lg:px-44 mx-2 py-12 lg:py-8 border-red-300">
        <h3 className="text-3xl leading-6 font-medium text-center pt-10 pb-8 text-white">
          Discover Catagories
        </h3>
        <Tabs />
        <Discover_Categories />
      </div>

      <div className="px-8 sm:px-20 lg:px-44 mx-2 py-12 lg:py-8 border-red-300">
        <h3 className="text-3xl leading-6 font-medium text-center pt-10 text-white">
          Our Team
        </h3>
        <p className="text-xs text-center  pt-6 text-white">
          Lorem’s dedicated technical team working effeciently 24/7 to meet the
          customer needs
        </p>
        <Team />
      </div>

      <div className="px-8 sm:px-20 lg:px-44 mx-2 py-12 lg:py-8 ">
        <h3 className="text-3xl leading-6 font-medium text-center pt-10 pb-2 text-white">
        Our Advisors
        </h3>
        <Advisor />
      </div>

      <div className="px-8 sm:px-20 lg:px-44 mx-2 py-12 mt-24 lg:py-8 ">
        <div className="h-80 relative w-full gradient-color rounded-3xl">
        <img
              src={Images.Mobile_Mockups}
              alt=""
              className="absolute img -top-52 object-contain w-full "
            />
        </div>
      </div>
    </div>
  );
};

export default App;
