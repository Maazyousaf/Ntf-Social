import { Images } from "./Images";

export const Feature = [
  {
    img: Images.Icon1,
    heading: "Swipe Swap",
    pera: "Discover new and unique NFTs with our Tinder-style swipe and match feature, Swipe Swap, which will recommend you NFTs based on your interests.",
  },
  {
    img: Images.Icon2,
    heading: "Aggregated Marketplace",
    pera: "Buy and sell NFTs on our Aggregated Marketplace – our dedicated marketplace listing all NFTs for sale from various popular NFT marketplaces. Boost your impressions by utilizing our self-promotion features.",
  },
  {
    img: Images.Icon3,
    heading: "Art Lottery",
    pera: "Get an ART Lottery ticket with every swap or purchase tickets directly and you could be one of our weekly Lottery winners, receiving a pot of $ART tokens and a rare NFT. ",
  },
  {
    img: Images.Icon4,
    heading: "Social Platform",
    pera: "Engage with other users and their content – follow their accounts, like, comment, and bid on their NFTs. Create NFT playlists, forums, and more.",
  },
  {
    img: Images.Icon5,
    heading: "Swap Auctions",
    pera: "Play our Art Auctions – countdown-style bids that award the NFT to the highest bidder. Compete for the winning bid in Party Mode, or use Silent-Auction Mode to discretely place your offers. Auctioneers receive bonus ART Lottery tickets upon sale!",
  },
  {
    img: Images.Icon6,
    heading: "MyArt",
    pera: "Create your personal profile where you can define your interests, and display your NFTs in a personalized way. Choose your avatar and how you want to showcase your collectibles. Add friends, and connect to Buyers/Sellers in a new way via direct message.",
  },
  {
    img: Images.Icon7,
    heading: "NFT Vault",
    pera: "Safely and securely store your precious NFTs in your personal NFT Vault. Accessible by password on browser version or using Face ID on iPhone, Swap Vault ensures an extra layer of security with 2FA and platform insurance protocols.",
  },
];

export const Comunity = [
  {
    heading: "Gaming LFG",
    img1: Images.Art1,
    img2: Images.Art2,
    img3: Images.Art3,
    img4: Images.Art4,
  },
];

export const Tabs = [
  { name: "Memes", href: "#", current: false },
  { name: "Games", href: "#", current: true },
  { name: "Skins", href: "#", current: false },
  { name: "Virtual Land", href: "#", current: false },
  { name: "AR", href: "#", current: false },
  { name: "VR", href: "#", current: false },
  { name: "Avatars", href: "#", current: false },
  { name: "Collectibles", href: "#", current: false },
  { name: "Trading Cards", href: "#", current: false },
  { name: "Pets", href: "#", current: false },
];

export const Discover = [
  { src: Images.Discovery_1 },
  { src: Images.Discovery_2 },
  { src: Images.Discovery_3 },
  { src: Images.Discovery_4 },
  { src: Images.Discovery_5 },
  { src: Images.Discovery_6 },
  { src: Images.Discovery_7 },
  { src: Images.Discovery_8 },
  { src: Images.Discovery_9 },
  { src: Images.Discovery_10 },
];

export const Team = [
    {
      name: "Lorem Ipsum",
      title: "CEO / Co-Founder",
      role: "LinkedIn",
      imageUrl:
        "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=4&w=256&h=256&q=60",
    },
    {
        name: "Lorem Ipsum",
        title: "CEO / Co-Founder",
        role: "LinkedIn",
        imageUrl:
          "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=4&w=256&h=256&q=60",
    },
    {
        name: "Lorem Ipsum",
        title: "CEO / Co-Founder",
        role: "LinkedIn",
        imageUrl:
          "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=4&w=256&h=256&q=60",
    },
    {
        name: "Lorem Ipsum",
        title: "CEO / Co-Founder",
        role: "LinkedIn",
        imageUrl:
          "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=4&w=256&h=256&q=60",
    },
    {
        name: "Lorem Ipsum",
        title: "CEO / Co-Founder",
        role: "LinkedIn",
        imageUrl:
          "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=4&w=256&h=256&q=60",
    },
    {
        name: "Lorem Ipsum",
        title: "CEO / Co-Founder",
        role: "LinkedIn",
        imageUrl:
          "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=4&w=256&h=256&q=60",
    },
    {
        name: "Lorem Ipsum",
        title: "CEO / Co-Founder",
        role: "LinkedIn",
        imageUrl:
          "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=4&w=256&h=256&q=60",
    },
    {
        name: "Lorem Ipsum",
        title: "CEO / Co-Founder",
        role: "LinkedIn",
        imageUrl:
          "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=4&w=256&h=256&q=60",
      },
      {
        name: "Lorem Ipsum",
        title: "CEO / Co-Founder",
        role: "LinkedIn",
        imageUrl:
          "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=4&w=256&h=256&q=60",
    },
    {
        name: "Lorem Ipsum",
        title: "CEO / Co-Founder",
        role: "LinkedIn",
        imageUrl:
          "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=4&w=256&h=256&q=60",
      },

    
  ];


  export const Advisor = [
    {
      name: "Lorem Ipsum",
      title: "CEO / Co-Founder",
      role: "LinkedIn",
      imageUrl:
        "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=4&w=256&h=256&q=60",
      },
      {
        name: "Lorem Ipsum",
        title: "CEO / Co-Founder",
        role: "LinkedIn",
        imageUrl:
          "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=4&w=256&h=256&q=60",
      },
      {
        name: "Lorem Ipsum",
        title: "CEO / Co-Founder",
        role: "LinkedIn",
        imageUrl:
          "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=4&w=256&h=256&q=60",
      },
      
  ]