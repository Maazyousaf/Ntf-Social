import Art_1 from "../../Assests/Images/Art_1.png";
export default function Example() {
  return (
    <div>
      
      <li className="p-6 bg-gray-800 rounded-lg shadow">
        <h2 className="text-lg font-medium text-white">Our Community</h2>
        <div className="grid  pt-4 gap-6 sm:gap-3 grid-cols-2">
          <img
            src={Art_1}
            alt=""
            className="object-cover pointer-events-none group-hover:opacity-75"
          />
          <img
            src={Art_1}
            alt=""
            className="object-cover pointer-events-none group-hover:opacity-75"
          />
          <img
            src={Art_1}
            alt=""
            className="object-cover pointer-events-none group-hover:opacity-75"
          />
          <img
            src={Art_1}
            alt=""
            className="object-cover pointer-events-none group-hover:opacity-75"
          />
        </div>
        <div className="flex pt-4 justify-between">
          <h2 className="text-sm  truncate font-medium text-white">
            Create Your World
          </h2>
          <div className=" flex items-center">
            <svg
              width="26"
              height="28"
              viewBox="0 0 26 28"
              fill="none"
              className="mr-3"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M22.4499 0H3.68992C2.10792 0 0.819916 1.288 0.819916 2.884V21.812C0.819916 23.408 2.10792 24.696 3.68992 24.696H19.5659L18.8239 22.106L20.6159 23.772L22.3099 25.34L25.3199 28V2.884C25.3199 1.288 24.0319 0 22.4499 0ZM17.0459 18.284C17.0459 18.284 16.5419 17.682 16.1219 17.15C17.9559 16.632 18.6559 15.484 18.6559 15.484C18.0819 15.862 17.5359 16.128 17.0459 16.31C16.3459 16.604 15.6739 16.8 15.0159 16.912C13.6719 17.164 12.4399 17.094 11.3899 16.898C10.5919 16.744 9.90592 16.52 9.33192 16.296C9.00992 16.17 8.65992 16.016 8.30992 15.82C8.26792 15.792 8.22592 15.778 8.18392 15.75C8.15592 15.736 8.14192 15.722 8.12792 15.708C7.87592 15.568 7.73592 15.47 7.73592 15.47C7.73592 15.47 8.40792 16.59 10.1859 17.122C9.76592 17.654 9.24792 18.284 9.24792 18.284C6.15392 18.186 4.97792 16.156 4.97792 16.156C4.97792 11.648 6.99392 7.994 6.99392 7.994C9.00992 6.482 10.9279 6.524 10.9279 6.524L11.0679 6.692C8.54792 7.42 7.38592 8.526 7.38592 8.526C7.38592 8.526 7.69392 8.358 8.21192 8.12C9.70992 7.462 10.8999 7.28 11.3899 7.238C11.4739 7.224 11.5439 7.21 11.6279 7.21C12.4819 7.098 13.4479 7.07 14.4559 7.182C15.7859 7.336 17.2139 7.728 18.6699 8.526C18.6699 8.526 17.5639 7.476 15.1839 6.748L15.3799 6.524C15.3799 6.524 17.2979 6.482 19.3139 7.994C19.3139 7.994 21.3299 11.648 21.3299 16.156C21.3299 16.156 20.1399 18.186 17.0459 18.284Z"
                fill="#7289DA"
              />
            </svg>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              class="h-7 w-7"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fill-rule="evenodd"
                d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z"
                clip-rule="evenodd"
              />
            </svg>
          </div>
        </div>
      </li>
    </div>
  );
}
